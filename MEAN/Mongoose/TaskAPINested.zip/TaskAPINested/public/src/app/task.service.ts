import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class TaskService {

  constructor(private _http: HttpClient) { 

  }

  getAllTask(){
    return this._http.get("/api");
  }
  
  getOneTask(id){
    return this._http.get(`/api/task/${id}`);
  }

  createTask(newTask){
    return this._http.post("/api/task/create", newTask);
  }

  updateTask(updateTask){
    return this._http.put(`api/task/update/${updateTask._id}`, updateTask);
  }

  destroyTask(id){
    return this._http.delete(`api/task/destroy/${id}`);
  }
}
