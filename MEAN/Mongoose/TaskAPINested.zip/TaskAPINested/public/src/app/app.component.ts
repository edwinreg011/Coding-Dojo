import { Component, OnInit } from '@angular/core';
import { TaskService } from "./task.service";
import { observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'Task Master!';
  allTasks:any;
  oneTask:any;
  newTask:any;
  errors: string[] =[];
  editTask: any;
  editErrors: string[] = [];
  constructor(private _taskService: TaskService){};

  ngOnInit(){
    this.newTask = {
      title: "",
      description: ""
    }
  }

  getTasksFromService(){
    let obs = this._taskService.getAllTask();
    obs.subscribe(data => {
      console.log(data);
      if(data["results"]){
        this.allTasks = data["results"];
      }
    })
  }

  getOneTaskFromService(id){
    let obs = this._taskService.getOneTask(id);
    obs.subscribe(data => {
      if(data["results"]){
        this.oneTask = data["results"];
      }
    })
  }

  createTask(){
    this.errors = []; 
    let obs = this._taskService.createTask(this.newTask);
    obs.subscribe(data => {
      if(data["results"]){
        this.newTask = {
          title: "",
          description: ""
        }
        this.getTasksFromService();
      }
      else if (data["errors"]){
        for(var key in data["errors"]){
          this.errors.push(data["errors"][key]["message"]);
        }
      }
    })
  }

  getEditTask(id){
    let obs = this._taskService.getOneTask(id);
    obs.subscribe(data => {
      if(data["results"]){
        this.editTask = data["results"];
      }
    })
  }

  updateTask(){
    this.editErrors = [];
    let obs = this._taskService.updateTask(this.editTask)
    obs.subscribe(data=> {
      if(data["results"]){
        this.editTask = null;
        this.getTasksFromService();
      }
      else if(data["errors"]){
        for(var key in data["errors"]){
          this.editErrors.push(data["errors"][key]["message"]);
        }
      }
    })
  }

  destroyTask(id){
    let obs = this._taskService.destroyTask(id);
    obs.subscribe(data=> {
      if(data["results"]){
        this.getTasksFromService();
      }
    })
  }
}
